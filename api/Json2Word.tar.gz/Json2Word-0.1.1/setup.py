from setuptools import find_packages, setup
setup(
    name='Json2Word',
    packages=find_packages(),
    version='0.1.1',
    description='Json interpreter for composing word documents.',
    author='Andreas Löfkvist',
    author_email='andreasmlofkvist@gmail.com',
    license='MIT',
    setup_requires=['python-docx','pillow','numpy','requests']
)